import numpy as np

# 读取包含字典的.npy文件
pre_train = np.load("/data2/wangyuan/IMed-361M_dataset/ACDC/imask/x___patient001_frame01_1.npy", allow_pickle=True, encoding="latin1")
data_dic = pre_train.item()

print(type(data_dic))
print(data_dic['conv1_1']) # 返回一个列表，该列表有两个array，表示conv1_1的权重w与偏置b
print((data_dic['conv1_1'][0]).shape)

